mkdir ~/drawtools
cp * ~/drawtools
sudo ln -s $HOME/drawtools/rectangle /bin/rectangle
sudo ln -s $HOME/drawtools/circle /bin/circle
sudo ln -s $HOME/drawtools/arc /bin/arc
sudo ln -s $HOME/drawtools/elipse /bin/elipse
sudo ln -s $HOME/drawtools/draw /bin/draw
sudo ln -s $HOME/drawtools/drawpic /bin/drawpic
